my-dynamic-website/
|-- app/
|   |-- templates/
|   |   |-- index.html
|-- static/
|   |-- css/
|   |   |-- style.css
|-- functions/
|   |-- main.py
|   |-- requirements.txt
|   |-- index.js
|-- public/
|-- .firebaserc
|-- firebase.json

